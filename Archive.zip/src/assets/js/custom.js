$(document).ready(function () {
    // show/hide map
    $('body').on('click', '#js_open_map', function () {
        $('#gmap_footer').slideToggle();
    });
});