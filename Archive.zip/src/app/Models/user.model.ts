export class User {
  success: boolean
  data: {
    id: number,
    token: string,
    branchid: string
,    printer: string

  }
}
