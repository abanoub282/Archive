import { Injectable } from '@angular/core';
import { from as fromPromise, Observable, throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import * as qz from 'qz-tray';
import { sha256 } from 'js-sha256';
import * as shajs from 'sha.js';

@Injectable({
  providedIn: 'root'
})
export class PrinterService {

  constructor() {


  }
  // Get the list of printers connected
  getPrinters(): Observable<string[]> {
    return fromPromise(
      qz.websocket.connect().then(() => qz.printers.find())
    ).pipe(map((printers: string[]) => printers), catchError(this.errorHandler))
  }
  // Get the SPECIFIC connected printer
  getPrinter(printerName: string): Observable<string> {
    return fromPromise(
      qz.websocket.connect()
        .then(() => qz.printers.find(printerName))
    ).pipe(map((printer: string) => printer), catchError(this.errorHandler))
  }

  // Print data to chosen printer
  printData(printer: string, data: any): Observable<any> {
    const config = qz.configs.create(printer);

    return fromPromise(qz.print(config, data)).pipe(map((anything: any) => anything)
      , catchError(this.errorHandler))

  }

  private errorHandler(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.log(error.error);
      console.log('An error occurred:', error.status);
      return throwError(error.error);
    } else {
      console.log('An error occurred:', error.status);
      console.log(error.error);
      return throwError(error.error);
    }
  };
}
