export const environment = {
  production: true,
  serverUrl: 'http://wokhouse.codesroots.com/api/'

};
